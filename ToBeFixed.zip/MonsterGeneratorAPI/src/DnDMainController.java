import javafx.fxml.FXML;
import javafx.scene.control.Label;
import javafx.scene.layout.HBox;

public class PleaseProvideControllerClassName {

    @FXML
    private Label alignment;

    @FXML
    private HBox name;

    @FXML
    private Label size;

    @FXML
    private Label type;

}
