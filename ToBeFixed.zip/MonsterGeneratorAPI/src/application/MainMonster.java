package application;

import java.io.IOException;

public class MainMonster {

	public static void main(String[] args) throws IOException {

		MonsterParser parse = new MonsterParser();
		MonsterMethods methodTest = new MonsterMethods();

		// parse.testParser();
		methodTest.monsSlug();
		System.out.println("\n");
		methodTest.toUrl(methodTest.monsSlug());
	}

}
