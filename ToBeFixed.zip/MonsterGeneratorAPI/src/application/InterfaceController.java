package application;

import javafx.fxml.FXML;
import javafx.scene.control.Label;
import javafx.scene.layout.HBox;

public class InterfaceController {

    @FXML
    private Label alignment;

    @FXML
    private HBox name;

    @FXML
    private Label size;

    @FXML
    private Label type;
    
    @FXML
    void updateLabel(ActionEvent event) {
    	name.setText(monsSlug());
    	
    }

}
